package com.cg.app.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="users")
public class User {
	@Id
	@Column(name="user_id", length=10)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name="fName", length=15)
	private String fName;
	
	@Column(name="lName", length=15)
	private String lName;
	
	@Column(name="phoneNo", length=10)
	private long phoneNo;
	
	@Column(name="address", length=50)
	private String address;
	
	@Column(name="email", length=30)
	private String email;
	
	@Column(name="password", length=16)
	private String password;
	
	@OneToMany(mappedBy="user", cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	private Set<Feedback> feedback;
	
	
	
	public Set<Feedback> getFeedback() {
		return feedback;
	}
	public void setFeedback(Set<Feedback> feedback) {
		this.feedback = feedback;
	}
	//	@OneToMany(cascade = CascadeType.ALL)
//	@JoinColumn(name = "uf_fk", referencedColumnName = "user_id")
//	private List<Feedback> feedback = new ArrayList();
//	
//
//	public List<Feedback> getFeedback() {
//		return feedback;
//	}
//	public void setFeedback(List<Feedback> feedback) {
//		this.feedback = feedback;
//	}
	public User() {
	}
	public User(int id, String fName, String lName, long phoneNo, String address, String email,
			String password) {
		super();
		this.id = id;
		this.fName = fName;
		this.lName = lName;
		this.phoneNo = phoneNo;
		this.address = address;
		this.email = email;
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
