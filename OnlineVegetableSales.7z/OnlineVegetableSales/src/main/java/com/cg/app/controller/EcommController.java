package com.cg.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.app.model.Feedback;
import com.cg.app.model.User;
import com.cg.app.repository.FeedbackRepository;
import com.cg.app.repository.UserRepository;
import com.cg.app.service.EcommService;
import java.util.*;
import javassist.NotFoundException;

@RestController
@RequestMapping("/api")
public class EcommController {

	@Autowired
	private EcommService service;
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private FeedbackRepository feedbackRepo;
	
	@PostMapping("/registerUser")
	@CrossOrigin(origins = "http://localhost:4200")
	public User registerUser(@RequestBody User user) throws Exception {
		String tempEmailId = user.getEmail();
		if(tempEmailId != null && !"".equals(tempEmailId)) {
			User userObj = service.fetchUserByEmailId(tempEmailId);
			if(userObj != null) {
				throw new Exception("User with "+tempEmailId+" is already exist");
			}
		}
		User userObj = null;
		userObj = service.saveUser(user);
		return userObj;
	}
	
	@PostMapping("/login")
	@CrossOrigin(origins = "http://localhost:4200")
	public User loginUser(@RequestBody User user) throws Exception {
		String tempEmailId = user.getEmail();
		String tempPass = user.getPassword();
		User userObj = null;
		if(tempEmailId != null && tempPass != null) {
			userObj = service.fetchUserByEmailAndPassword(tempEmailId, tempPass);
		}
		if(userObj == null) {
			throw new Exception("Bad credentials");
		}
		return userObj;
	}
	
	@PostMapping("/users/{email}/comments")
	@CrossOrigin(origins = "http://localhost:4200")
	public Feedback addFeedback(@PathVariable String email,
			 @Validated @RequestBody Feedback feedback) throws NotFoundException {
					User user = service.fetchUserByEmailId(email);
                	feedback.setUser(user);
                    return service.addFeedback(feedback, email);
               
	}
	
//	@PostMapping("/userFeedback")
//	@CrossOrigin(origins = "http://localhost:4200")
//	public Feedback userFeedback(@RequestBody User user, Feedback feedback) throws Exception {
//		String tempEmailId = user.getEmail();
//		//System.out.println(tempEmailId);
//		Feedback feedbackObj = null;
//		if(tempEmailId != null && !"".equals(tempEmailId)) {
//			User userObj = service.fetchUserByEmailId(tempEmailId);
//			if(userObj != null) {
//				feedbackObj = service.addFeedback(feedback);
//			}
//			else {
//				throw new Exception("User is not exist");
//			}
//		}
//		return feedbackObj;
//	}
	
}
