package com.cg.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.model.Feedback;
import com.cg.app.model.User;
import com.cg.app.repository.FeedbackRepository;
import com.cg.app.repository.UserRepository;

@Service
public class EcommService {

	@Autowired
	private UserRepository userRepo;
	@Autowired 
	private FeedbackRepository feedbackRepo;
	
	public User saveUser(User user) {
		return userRepo.save(user);
	}
	
	public User fetchUserByEmailId(String email) {
		return userRepo.findByEmail(email);
	}
	
	public User fetchUserByEmailAndPassword(String email, String password) {
		return userRepo.findByEmailAndPassword(email, password);
	}
	
	public Feedback addFeedback(Feedback feedback, String emailId) {
		return feedbackRepo.save(feedback);
	}
}
